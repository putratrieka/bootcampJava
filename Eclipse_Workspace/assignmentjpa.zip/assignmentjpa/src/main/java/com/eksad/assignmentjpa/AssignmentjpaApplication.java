package com.eksad.assignmentjpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AssignmentjpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(AssignmentjpaApplication.class, args);
	}

}
