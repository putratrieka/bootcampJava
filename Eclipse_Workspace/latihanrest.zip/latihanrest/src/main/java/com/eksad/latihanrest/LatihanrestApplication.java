package com.eksad.latihanrest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LatihanrestApplication {

	public static void main(String[] args) {
		SpringApplication.run(LatihanrestApplication.class, args);
	}

}
